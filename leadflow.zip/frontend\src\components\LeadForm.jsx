import { useState, useEffect } from 'react';

const LeadForm = ({ onSubmit, editableLead }) => {
    const [form, setForm] = useState({ title: '', email: '', company: '', status: 'new' });

    useEffect(() => {
        if (editableLead) {
            setForm({
                title: editableLead.title,
                email: editableLead.email,
                company: editableLead.company || '',
                status: editableLead.status,
            });
        }
    }, [editableLead]);

    const handleChange = (event) => {
        const { name, value } = event.target;
        setForm((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        onSubmit(form);
        if (!editableLead) {
            setForm({ title: '', email: '', company: '', status: 'new' });
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
            <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Titre du lead</label>
                <input
                    name="title"
                    value={form.title}
                    onChange={handleChange}
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none focus:border-brand-500"
                    placeholder="Idée de contact ou opportunité"
                />
            </div>
            <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Email</label>
                <input
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none focus:border-brand-500"
                    placeholder="contact@entreprise.com"
                />
            </div>
            <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Entreprise</label>
                <input
                    name="company"
                    value={form.company}
                    onChange={handleChange}
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none focus:border-brand-500"
                    placeholder="Société"
                />
            </div>
            <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">Statut</label>
                <select
                    name="status"
                    value={form.status}
                    onChange={handleChange}
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none focus:border-brand-500"
                >
                    <option value="new">Nouveau</option>
                    <option value="contacted">Contacté</option>
                    <option value="qualified">Qualifié</option>
                    <option value="closed">Clos</option>
                </select>
            </div>
            <button className="w-full rounded-2xl bg-brand-500 px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-700">
                {editableLead ? 'Mettre à jour le lead' : 'Créer un lead'}
            </button>
        </form>
    );
};

export default LeadForm;
