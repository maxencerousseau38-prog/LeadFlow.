import { useState, useEffect } from 'react';

export const useAuth = () => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const stored = localStorage.getItem('leadflow_user');
        if (stored) setUser(JSON.parse(stored));
    }, []);

    return { user, setUser };
};
