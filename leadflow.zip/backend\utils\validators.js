const validateEmail = (value) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
};

const validateRegister = ({ name, email, password }) => {
    if (!name || !email || !password) return 'Tous les champs sont requis.';
    if (!validateEmail(email)) return 'L’adresse e-mail est invalide.';
    if (password.length < 6) return 'Le mot de passe doit contenir au moins 6 caractères.';
    return null;
};

const validateLogin = ({ email, password }) => {
    if (!email || !password) return 'Email et mot de passe sont nécessaires.';
    if (!validateEmail(email)) return 'L’adresse e-mail est invalide.';
    return null;
};

const validateLead = ({ title, email }) => {
    if (!title || !email) return 'Titre et e-mail sont requis pour un lead.';
    if (!validateEmail(email)) return 'L’adresse e-mail du lead est invalide.';
    return null;
};

module.exports = { validateRegister, validateLogin, validateLead };
