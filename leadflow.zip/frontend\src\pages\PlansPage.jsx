import { useState } from 'react';
import { upgradePlan, downgradePlan } from '../services/subscription';
import toast from 'react-hot-toast';

const PlansPage = ({ user, setUser }) => {
    const [loading, setLoading] = useState(false);

    const handleUpgrade = async () => {
        setLoading(true);
        try {
            const result = await upgradePlan();
            setUser({ ...user, plan: result.plan });
            localStorage.setItem('leadflow_user', JSON.stringify({ ...user, plan: result.plan }));
            toast.success(result.message);
        } catch (error) {
            toast.error(error.response?.data?.message || 'Erreur d’abonnement.');
        } finally {
            setLoading(false);
        }
    };

    const handleDowngrade = async () => {
        setLoading(true);
        try {
            const result = await downgradePlan();
            setUser({ ...user, plan: result.plan });
            localStorage.setItem('leadflow_user', JSON.stringify({ ...user, plan: result.plan }));
            toast.success(result.message);
        } catch (error) {
            toast.error('Impossible de rétrograder.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-8">
            <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-soft">
                <h1 className="text-3xl font-semibold text-slate-900">Abonnement</h1>
                <p className="mt-2 text-slate-600">Choisissez un plan moderne adapté à votre workflow.</p>
            </section>

            <div className="grid gap-6 lg:grid-cols-2">
                <div className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-soft">
                    <p className="text-sm uppercase tracking-[0.2em] text-slate-500">Plan Free</p>
                    <h2 className="mt-4 text-3xl font-semibold text-slate-900">Gratuit</h2>
                    <p className="mt-4 text-slate-600">Accès standard avec jusqu’à 5 leads actifs. Parfait pour tester la plateforme.</p>
                    <ul className="mt-6 space-y-3 text-slate-600">
                        <li>✅ Gestion des leads</li>
                        <li>✅ Tableau de bord moderne</li>
                        <li>✅ Authentification sécurisée</li>
                    </ul>
                    <div className="mt-8">
                        <button
                            onClick={handleDowngrade}
                            disabled={loading || user.plan === 'free'}
                            className="w-full rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-900 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {user.plan === 'free' ? 'Plan actif' : 'Passer au gratuit'}
                        </button>
                    </div>
                </div>

                <div className="rounded-[28px] border border-brand-200 bg-brand-50 p-8 shadow-soft">
                    <p className="text-sm uppercase tracking-[0.2em] text-brand-700">Plan Premium</p>
                    <h2 className="mt-4 text-3xl font-semibold text-slate-900">Premium</h2>
                    <p className="mt-4 text-slate-700">Lead illimités, priorité support, et accès à toutes les fonctionnalités.</p>
                    <ul className="mt-6 space-y-3 text-slate-700">
                        <li>✅ Leads illimités</li>
                        <li>✅ Priorité support</li>
                        <li>✅ Rapports avancés</li>
                    </ul>
                    <div className="mt-8">
                        <button
                            onClick={handleUpgrade}
                            disabled={loading || user.plan === 'premium'}
                            className="w-full rounded-2xl bg-brand-700 px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-900 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {user.plan === 'premium' ? 'Plan actif' : 'Passer au premium'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PlansPage;
