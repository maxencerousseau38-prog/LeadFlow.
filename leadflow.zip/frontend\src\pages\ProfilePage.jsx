const ProfilePage = ({ user }) => {
    return (
        <div className="space-y-8">
            <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-soft">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div>
                        <p className="text-sm text-slate-500">Profil utilisateur</p>
                        <h1 className="mt-2 text-3xl font-semibold text-slate-900">{user.name}</h1>
                    </div>
                    <div className="rounded-3xl bg-slate-50 px-6 py-4 text-slate-700">
                        <p className="text-sm uppercase tracking-[0.2em] text-slate-500">Plan actuel</p>
                        <p className="mt-2 text-2xl font-semibold text-slate-900">{user.plan}</p>
                    </div>
                </div>
            </section>

            <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-soft">
                <h2 className="text-xl font-semibold text-slate-900">Détails du compte</h2>
                <div className="mt-6 grid gap-6 md:grid-cols-2">
                    <div className="rounded-3xl bg-slate-50 p-6">
                        <p className="text-sm text-slate-500">Adresse e-mail</p>
                        <p className="mt-3 text-lg font-semibold text-slate-900">{user.email}</p>
                    </div>
                    <div className="rounded-3xl bg-slate-50 p-6">
                        <p className="text-sm text-slate-500">Nom complet</p>
                        <p className="mt-3 text-lg font-semibold text-slate-900">{user.name}</p>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default ProfilePage;
