import { motion } from 'framer-motion';
import Navbar from './Navbar';

const Layout = ({ user, setUser, children }) => {
    return (
        <div className="min-h-screen bg-slate-50">
            <Navbar user={user} setUser={setUser} />
            <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4 }}
                >
                    {children}
                </motion.div>
            </main>
        </div>
    );
};

export default Layout;
