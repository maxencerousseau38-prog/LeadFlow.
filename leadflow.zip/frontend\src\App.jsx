import { AnimatePresence, motion } from 'framer-motion';
import { Route, Routes, Navigate, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import PlansPage from './pages/PlansPage';
import ProfilePage from './pages/ProfilePage';
import Layout from './components/Layout';
import { getProfile } from './services/auth';
import './App.css';

function App() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const location = useLocation();

    useEffect(() => {
        const fetchProfile = async () => {
            const profile = await getProfile();
            setUser(profile?.user || null);
            setLoading(false);
        };
        fetchProfile();
    }, []);

    const authenticated = Boolean(user);

    return (
        <div className="min-h-screen bg-slate-50 text-slate-900">
            <Toaster position="top-right" />
            <AnimatePresence mode="wait">
                <Routes location={location} key={location.pathname}>
                    <Route
                        path="/auth"
                        element={<AuthPage setUser={setUser} />}
                    />
                    <Route
                        path="/"
                        element={authenticated ? <Layout user={user} setUser={setUser}><DashboardPage user={user} /></Layout> : <Navigate to="/auth" />}
                    />
                    <Route
                        path="/plans"
                        element={authenticated ? <Layout user={user} setUser={setUser}><PlansPage user={user} setUser={setUser} /></Layout> : <Navigate to="/auth" />}
                    />
                    <Route
                        path="/profile"
                        element={authenticated ? <Layout user={user} setUser={setUser}><ProfilePage user={user} /></Layout> : <Navigate to="/auth" />}
                    />
                    <Route path="*" element={<Navigate to={authenticated ? '/' : '/auth'} />} />
                </Routes>
            </AnimatePresence>
        </div>
    );
}

export default App;
