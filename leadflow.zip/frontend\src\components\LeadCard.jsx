const LeadCard = ({ lead, onEdit, onDelete }) => {
    return (
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-soft">
            <div className="mb-4 flex items-start justify-between gap-4">
                <div>
                    <h3 className="text-lg font-semibold text-slate-900">{lead.title}</h3>
                    <p className="text-sm text-slate-500">{lead.company || 'Entreprise non renseignée'}</p>
                </div>
                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
                    {lead.status}
                </span>
            </div>
            <div className="space-y-2 text-sm text-slate-600">
                <p>Email : <span className="font-medium text-slate-900">{lead.email}</span></p>
                <p>Créé le : {new Date(lead.createdAt).toLocaleDateString()}</p>
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
                <button
                    onClick={() => onEdit(lead)}
                    className="rounded-2xl bg-brand-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-700"
                >
                    Modifier
                </button>
                <button
                    onClick={() => onDelete(lead._id)}
                    className="rounded-2xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
                >
                    Supprimer
                </button>
            </div>
        </div>
    );
};

export default LeadCard;
