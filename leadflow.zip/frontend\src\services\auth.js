import api from './api';

export const registerUser = async (payload) => {
    const response = await api.post('/auth/register', payload);
    return response.data;
};

export const loginUser = async (payload) => {
    const response = await api.post('/auth/login', payload);
    return response.data;
};

export const getProfile = async () => {
    try {
        const response = await api.get('/auth/me');
        return response.data;
    } catch (error) {
        return null;
    }
};

export const saveSession = ({ token, user }) => {
    localStorage.setItem('leadflow_token', token);
    localStorage.setItem('leadflow_user', JSON.stringify(user));
};

export const logout = () => {
    localStorage.removeItem('leadflow_token');
    localStorage.removeItem('leadflow_user');
};
