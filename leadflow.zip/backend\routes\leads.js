const express = require('express');
const Lead = require('../models/Lead');
const auth = require('../middleware/auth');
const { validateLead } = require('../utils/validators');

const router = express.Router();

router.use(auth);

router.get('/', async (req, res) => {
    const leads = await Lead.find({ owner: req.user._id }).sort({ createdAt: -1 });
    res.json({ leads });
});

router.post('/', async (req, res) => {
    const error = validateLead(req.body);
    if (error) return res.status(400).json({ message: error });

    const existingLeads = await Lead.countDocuments({ owner: req.user._id });
    if (req.user.plan === 'free' && existingLeads >= 5) {
        return res.status(403).json({ message: 'Limite de 5 leads pour le plan gratuit.' });
    }

    const lead = await Lead.create({ ...req.body, owner: req.user._id });
    res.status(201).json({ lead });
});

router.put('/:id', async (req, res) => {
    const error = validateLead(req.body);
    if (error) return res.status(400).json({ message: error });

    const lead = await Lead.findOneAndUpdate(
        { _id: req.params.id, owner: req.user._id },
        req.body,
        { new: true }
    );

    if (!lead) return res.status(404).json({ message: 'Lead introuvable.' });
    res.json({ lead });
});

router.delete('/:id', async (req, res) => {
    const lead = await Lead.findOneAndDelete({ _id: req.params.id, owner: req.user._id });
    if (!lead) return res.status(404).json({ message: 'Lead introuvable.' });
    res.json({ message: 'Lead supprimé avec succès.' });
});

module.exports = router;
