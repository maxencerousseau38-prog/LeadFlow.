const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { validateRegister, validateLogin } = require('../utils/validators');

const router = express.Router();

const createToken = (userId) => {
    return jwt.sign({ id: userId }, process.env.JWT_SECRET || 'secret123', {
        expiresIn: '7d',
    });
};

router.post('/register', async (req, res) => {
    const error = validateRegister(req.body);
    if (error) return res.status(400).json({ message: error });

    const { name, email, password } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) {
        return res.status(409).json({ message: 'Cet e-mail est déjà utilisé.' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email, password: hashedPassword });

    res.status(201).json({
        token: createToken(user._id),
        user: { id: user._id, name: user.name, email: user.email, plan: user.plan },
    });
});

router.post('/login', async (req, res) => {
    const error = validateLogin(req.body);
    if (error) return res.status(400).json({ message: error });

    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: 'Identifiants invalides.' });
    }

    res.json({
        token: createToken(user._id),
        user: { id: user._id, name: user.name, email: user.email, plan: user.plan },
    });
});

const auth = require('../middleware/auth');
router.get('/me', auth, async (req, res) => {
    const user = req.user;
    res.json({ user: { id: user._id, name: user.name, email: user.email, plan: user.plan } });
});

module.exports = router;
