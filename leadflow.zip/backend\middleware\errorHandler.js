const errorHandler = (err, req, res, next) => {
    const status = err.status || 500;
    res.status(status).json({
        message: err.message || 'Erreur serveur interne',
        stack: process.env.NODE_ENV === 'production' ? undefined : err.stack,
    });
};

module.exports = { errorHandler };
