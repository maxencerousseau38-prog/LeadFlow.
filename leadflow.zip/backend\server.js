const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const connectDb = require('./config/db');
const authRoutes = require('./routes/auth');
const leadRoutes = require('./routes/leads');
const subscriptionRoutes = require('./routes/subscription');
const { errorHandler } = require('./middleware/errorHandler');

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;

connectDb();

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173', credentials: true }));
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/leads', leadRoutes);
app.use('/api/subscription', subscriptionRoutes);

app.use(errorHandler);

app.listen(PORT, () => {
    console.log(`LeadFlow backend listening on port ${PORT}`);
});
