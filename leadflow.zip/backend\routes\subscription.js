const express = require('express');
const auth = require('../middleware/auth');
const router = express.Router();

router.use(auth);

router.get('/status', async (req, res) => {
    res.json({ plan: req.user.plan });
});

router.post('/upgrade', async (req, res) => {
    if (req.user.plan === 'premium') {
        return res.status(400).json({ message: 'Vous êtes déjà en premium.' });
    }

    req.user.plan = 'premium';
    await req.user.save();

    res.json({ message: 'Abonnement premium activé.', plan: req.user.plan });
});

router.post('/downgrade', async (req, res) => {
    req.user.plan = 'free';
    await req.user.save();
    res.json({ message: 'Vous êtes repassé au plan gratuit.', plan: req.user.plan });
});

module.exports = router;
