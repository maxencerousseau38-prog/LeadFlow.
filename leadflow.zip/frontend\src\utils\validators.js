export const validateAuth = ({ name, email, password, mode }) => {
    if (mode === 'register' && !name) return 'Le nom est requis.';
    if (!email || !password) return 'Email et mot de passe sont requis.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Email invalide.';
    if (password.length < 6) return 'Le mot de passe doit avoir 6 caractères minimum.';
    return null;
};

export const validateLead = ({ title, email }) => {
    if (!title || !email) return 'Titre et email sont requis.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Email invalide.';
    return null;
};
