import api from './api';

export const fetchSubscription = async () => {
    const response = await api.get('/subscription/status');
    return response.data;
};

export const upgradePlan = async () => {
    const response = await api.post('/subscription/upgrade');
    return response.data;
};

export const downgradePlan = async () => {
    const response = await api.post('/subscription/downgrade');
    return response.data;
};
