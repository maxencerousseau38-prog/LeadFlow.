const mongoose = require('mongoose');

const leadSchema = new mongoose.Schema({
    title: { type: String, required: true, trim: true, maxlength: 120 },
    email: { type: String, required: true, trim: true, lowercase: true },
    company: { type: String, trim: true, maxlength: 80 },
    status: { type: String, enum: ['new', 'contacted', 'qualified', 'closed'], default: 'new' },
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Lead', leadSchema);
