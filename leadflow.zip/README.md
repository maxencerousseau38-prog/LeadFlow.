# LeadFlow SaaS

LeadFlow est une plateforme SaaS moderne pour gérer et générer des leads automatiquement. Elle propose une interface simple, un tableau de bord professionnel, un système d'abonnement `free` / `premium`, une API Node.js sécurisée, et un frontend React + Tailwind.

## Structure du projet

- `backend/` : API Node.js + Express + MongoDB
- `frontend/` : Application React + Vite + Tailwind CSS

## Installation

1. Ouvrez deux terminaux.
2. Installez les dépendances backend :
   ```bash
   cd backend
   npm install
   ```
3. Installez les dépendances frontend :
   ```bash
   cd ../frontend
   npm install
   ```

## Configuration

1. Copiez le fichier d'exemple :
   ```bash
   cd backend
   copy .env.example .env
   ```
2. Ajustez `MONGO_URI`, `JWT_SECRET`, `CLIENT_URL`.

## Démarrage

- Backend : `cd backend && npm run dev`
- Frontend : `cd frontend && npm run dev`

## Fonctionnalités

- Inscription / Connexion
- Tableau de bord utilisateur
- CRUD de leads
- Plan gratuit / premium
- Authentification JWT
- Architecture prête pour production
