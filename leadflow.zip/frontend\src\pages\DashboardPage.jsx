import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import LeadForm from '../components/LeadForm';
import LeadCard from '../components/LeadCard';
import { createLead, deleteLead, fetchLeads, updateLead } from '../services/leads';
import { fetchSubscription } from '../services/subscription';

const DashboardPage = ({ user }) => {
    const [leads, setLeads] = useState([]);
    const [editableLead, setEditableLead] = useState(null);
    const [subscription, setSubscription] = useState(user.plan);
    const [loading, setLoading] = useState(true);

    const loadData = async () => {
        setLoading(true);
        try {
            const [leadData, subscriptionData] = await Promise.all([fetchLeads(), fetchSubscription()]);
            setLeads(leadData.leads);
            setSubscription(subscriptionData.plan);
        } catch (error) {
            toast.error('Impossible de charger les données.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    const handleSubmit = async (payload) => {
        try {
            if (editableLead) {
                const { lead } = await updateLead(editableLead._id, payload);
                setLeads((prev) => prev.map((item) => (item._id === lead._id ? lead : item)));
                toast.success('Lead mis à jour.');
            } else {
                const { lead } = await createLead(payload);
                setLeads((prev) => [lead, ...prev]);
                toast.success('Lead créé.');
            }
            setEditableLead(null);
        } catch (error) {
            toast.error(error.response?.data?.message || 'Erreur lead.');
        }
    };

    const handleDelete = async (id) => {
        try {
            await deleteLead(id);
            setLeads((prev) => prev.filter((lead) => lead._id !== id));
            toast.success('Lead supprimé.');
        } catch (error) {
            toast.error('Impossible de supprimer le lead.');
        }
    };

    return (
        <div className="space-y-8">
            <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-soft">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div>
                        <p className="text-sm text-slate-500">Bonjour, {user.name}</p>
                        <h1 className="mt-3 text-3xl font-semibold text-slate-900">Votre tableau de bord</h1>
                        <p className="mt-2 text-slate-600">Gestion de leads et performance de votre plan.</p>
                    </div>
                    <div className="rounded-3xl bg-slate-50 px-6 py-4 text-slate-700">
                        <p className="text-sm uppercase tracking-[0.2em] text-slate-500">Abonnement</p>
                        <p className="mt-2 text-2xl font-semibold text-slate-900">{subscription}</p>
                        <p className="text-sm text-slate-500">Limite de leads : {subscription === 'free' ? '5' : 'illimitée'}</p>
                    </div>
                </div>
            </section>

            <section className="grid gap-8 lg:grid-cols-[1.5fr_1fr]">
                <div className="space-y-6">
                    <div className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-soft">
                        <div className="mb-5 flex items-center justify-between">
                            <div>
                                <h2 className="text-xl font-semibold text-slate-900">Vos leads</h2>
                                <p className="mt-1 text-sm text-slate-500">Gérez vos contacts et suivez vos opportunités.</p>
                            </div>
                            <span className="rounded-full bg-brand-50 px-3 py-1 text-sm font-semibold text-brand-700">{leads.length} leads</span>
                        </div>
                        {loading ? (
                            <div className="rounded-3xl bg-slate-50 p-8 text-center text-slate-500">Chargement...</div>
                        ) : leads.length === 0 ? (
                            <div className="rounded-3xl bg-slate-50 p-8 text-center text-slate-500">Aucun lead pour l'instant.</div>
                        ) : (
                            <div className="space-y-4">
                                {leads.map((lead) => (
                                    <LeadCard key={lead._id} lead={lead} onEdit={setEditableLead} onDelete={handleDelete} />
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                <div className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-soft">
                    <h2 className="text-xl font-semibold text-slate-900">Ajouter un lead</h2>
                    <p className="mt-2 text-sm text-slate-500">Utilisez le formulaire ci-dessous pour créer ou mettre à jour un lead.</p>
                    <div className="mt-6">
                        <LeadForm onSubmit={handleSubmit} editableLead={editableLead} />
                    </div>
                </div>
            </section>
        </div>
    );
};

export default DashboardPage;
