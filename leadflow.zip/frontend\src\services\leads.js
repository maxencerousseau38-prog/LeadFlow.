import api from './api';

export const fetchLeads = async () => {
    const response = await api.get('/leads');
    return response.data;
};

export const createLead = async (payload) => {
    const response = await api.post('/leads', payload);
    return response.data;
};

export const updateLead = async (id, payload) => {
    const response = await api.put(`/leads/${id}`, payload);
    return response.data;
};

export const deleteLead = async (id) => {
    const response = await api.delete(`/leads/${id}`);
    return response.data;
};
