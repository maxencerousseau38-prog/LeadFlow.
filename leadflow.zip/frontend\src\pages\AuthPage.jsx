import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginUser, registerUser, saveSession } from '../services/auth';
import { validateAuth } from '../utils/validators';
import toast from 'react-hot-toast';

const AuthPage = ({ setUser }) => {
    const [mode, setMode] = useState('login');
    const [form, setForm] = useState({ name: '', email: '', password: '' });
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleChange = (event) => {
        setForm((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        const error = validateAuth({ ...form, mode });
        if (error) return toast.error(error);

        setLoading(true);
        try {
            const action = mode === 'register' ? registerUser : loginUser;
            const data = await action(form);
            saveSession(data);
            setUser(data.user);
            toast.success(`Bienvenue ${data.user.name}!`);
            navigate('/');
        } catch (err) {
            toast.error(err.response?.data?.message || 'Impossible de se connecter');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 px-4 py-12">
            <div className="w-full max-w-3xl overflow-hidden rounded-[32px] bg-slate-50 shadow-soft">
                <div className="grid gap-8 p-8 md:grid-cols-[1.2fr_1fr]">
                    <div className="space-y-6">
                        <div>
                            <p className="mb-2 text-sm uppercase tracking-[0.2em] text-brand-500">LeadFlow</p>
                            <h1 className="text-3xl font-semibold text-slate-900">{mode === 'register' ? 'Créer votre compte' : 'Bienvenue à nouveau'}</h1>
                            <p className="mt-3 text-sm text-slate-600">Gérez vos leads, suivez votre abonnement et développez votre pipeline en quelques clics.</p>
                        </div>
                        <div className="rounded-3xl bg-slate-100 p-6">
                            <p className="text-sm text-slate-600">Plan actuel :</p>
                            <h2 className="mt-2 text-xl font-semibold text-slate-900">Free + Premium simulé</h2>
                        </div>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-4 rounded-[28px] bg-white p-6 shadow-sm">
                        {mode === 'register' && (
                            <div>
                                <label className="block text-sm font-medium text-slate-700">Nom complet</label>
                                <input
                                    name="name"
                                    value={form.name}
                                    onChange={handleChange}
                                    className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand-500"
                                    placeholder="Marie Dupont"
                                />
                            </div>
                        )}
                        <div>
                            <label className="block text-sm font-medium text-slate-700">Email</label>
                            <input
                                name="email"
                                type="email"
                                value={form.email}
                                onChange={handleChange}
                                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand-500"
                                placeholder="contact@startup.com"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700">Mot de passe</label>
                            <input
                                name="password"
                                type="password"
                                value={form.password}
                                onChange={handleChange}
                                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-brand-500"
                                placeholder="••••••••"
                            />
                        </div>
                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full rounded-2xl bg-brand-500 px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {loading ? 'Chargement...' : mode === 'register' ? 'Créer mon compte' : 'Se connecter'}
                        </button>
                        <p className="text-center text-sm text-slate-600">
                            {mode === 'register' ? 'Vous avez déjà un compte ?' : 'Pas encore de compte ?'}{' '}
                            <button type="button" onClick={() => setMode(mode === 'register' ? 'login' : 'register')} className="font-semibold text-brand-500">
                                {mode === 'register' ? 'Se connecter' : 'Créer un compte'}
                            </button>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default AuthPage;
