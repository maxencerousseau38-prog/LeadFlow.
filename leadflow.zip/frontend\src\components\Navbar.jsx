import { Link, useNavigate } from 'react-router-dom';
import { logout } from '../services/auth';
import toast from 'react-hot-toast';

const Navbar = ({ user, setUser }) => {
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        setUser(null);
        toast.success('Déconnecté avec succès');
        navigate('/auth');
    };

    return (
        <header className="border-b border-slate-200 bg-white shadow-sm">
            <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
                <div>
                    <Link to="/" className="text-xl font-semibold text-slate-900">
                        LeadFlow
                    </Link>
                    <p className="text-sm text-slate-500">Tableau de bord & gestion de leads</p>
                </div>

                <nav className="flex items-center gap-3 text-sm font-medium text-slate-600">
                    <Link to="/" className="hover:text-slate-900">
                        Tableau de bord
                    </Link>
                    <Link to="/plans" className="hover:text-slate-900">
                        Abonnement
                    </Link>
                    <Link to="/profile" className="hover:text-slate-900">
                        Profil
                    </Link>
                    <button
                        onClick={handleLogout}
                        className="rounded-full bg-slate-900 px-4 py-2 text-white transition hover:bg-slate-700"
                    >
                        Déconnexion
                    </button>
                </nav>
            </div>
        </header>
    );
};

export default Navbar;
